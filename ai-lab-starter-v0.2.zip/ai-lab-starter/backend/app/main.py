"""AI LAB API foundation: persistent knowledge/feedback + OpenAI-compatible model adapter."""
from datetime import datetime, timezone
from typing import Literal
from uuid import uuid4
import os, sqlite3, json, re
from contextlib import contextmanager
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

DB_PATH = os.getenv('AI_LAB_DB', 'ai_lab.db')
MODEL_BASE_URL = os.getenv('MODEL_BASE_URL', '').rstrip('/')
MODEL_NAME = os.getenv('MODEL_NAME', '')
MODEL_API_KEY = os.getenv('MODEL_API_KEY', '')
SYSTEM_PROMPT = os.getenv('SYSTEM_PROMPT', 'أنت مساعد AI LAB. أجب بدقة ووضوح، وصرّح بعدم اليقين ولا تختلق مصادر.')
app = FastAPI(title='AI LAB API', version='0.2.0', description='Multi-specialist AI platform foundation')
app.add_middleware(CORSMiddleware, allow_origins=os.getenv('CORS_ORIGINS','http://localhost:3000,http://127.0.0.1:5500').split(','), allow_credentials=False, allow_methods=['GET','POST'], allow_headers=['*'])
MODULES = [
 {'id':'chat','name':'الشات العام','status':'model_required'}, {'id':'image','name':'إنشاء الصور','status':'provider_required'},
 {'id':'video','name':'إنشاء الفيديو','status':'provider_required'}, {'id':'code','name':'البرمجة','status':'model_required'},
 {'id':'web','name':'بناء المواقع','status':'model_required'}, {'id':'apps','name':'بناء التطبيقات','status':'model_required'},
 {'id':'games','name':'استوديو الألعاب','status':'model_required'}, {'id':'files','name':'تحليل الملفات','status':'planned'}]

def now(): return datetime.now(timezone.utc).isoformat()
@contextmanager
def db():
 c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row
 try: yield c; c.commit()
 finally: c.close()
@app.on_event('startup')
def init_db():
 with db() as c:
  c.execute('''CREATE TABLE IF NOT EXISTS knowledge(id TEXT PRIMARY KEY,title TEXT NOT NULL,content TEXT NOT NULL,tags TEXT,source TEXT,created_at TEXT,review_status TEXT)''')
  c.execute('''CREATE TABLE IF NOT EXISTS feedback(id TEXT PRIMARY KEY,module TEXT,prompt TEXT,model_answer TEXT,corrected_answer TEXT,note TEXT,created_at TEXT,status TEXT)''')

class ChatRequest(BaseModel):
 message:str=Field(min_length=1,max_length=12000)
 module:Literal['chat','image','video','code','web','apps','games','files']='chat'
 conversation_id:str|None=None
class KnowledgeRequest(BaseModel):
 title:str=Field(min_length=1,max_length=200); content:str=Field(min_length=1,max_length=30000)
 tags:list[str]=Field(default_factory=list,max_length=30); source:str=Field(default='user',max_length=200)
class FeedbackRequest(BaseModel):
 module:str; prompt:str=Field(min_length=1,max_length=12000); model_answer:str=Field(min_length=1,max_length=30000)
 corrected_answer:str=Field(min_length=1,max_length=30000); note:str=Field(default='',max_length=2000)
class ReviewRequest(BaseModel): approved:bool

@app.get('/api/health')
def health(): return {'status':'ok','service':'AI LAB API','version':'0.2.0','model_configured':bool(MODEL_BASE_URL and MODEL_NAME),'database':'sqlite'}
@app.get('/api/modules')
def modules(): return {'modules':MODULES}

def terms(s): return set(re.findall(r'[\w\u0600-\u06ff]{3,}',s.lower()))
def retrieve(query, limit=4):
 q=terms(query)
 if not q:return []
 with db() as c: rows=c.execute("SELECT * FROM knowledge WHERE review_status='approved' ORDER BY created_at DESC LIMIT 500").fetchall()
 scored=[]
 for r in rows:
  body=r['title']+' '+r['content']+' '+(r['tags'] or '')
  score=len(q & terms(body))
  if score: scored.append((score,dict(r)))
 return [x[1] for x in sorted(scored,key=lambda x:x[0],reverse=True)[:limit]]
@app.post('/api/chat')
async def chat(req:ChatRequest):
 if not MODEL_BASE_URL or not MODEL_NAME:
  raise HTTPException(503,detail={'code':'MODEL_NOT_CONFIGURED','message':'لم يتم ربط موديل محادثة بعد. اضبط MODEL_BASE_URL وMODEL_NAME في إعدادات الخادم.'})
 context=retrieve(req.message)
 system=SYSTEM_PROMPT
 if context:
  system += '\n\nمعلومات معتمدة من قاعدة معرفة AI LAB (استخدمها عند الصلة، ولا تعتبرها حقيقة إن تعارضت مع معرفة موثوقة):\n'+'\n'.join(f"- {x['title']}: {x['content']}" for x in context)
 headers={'Content-Type':'application/json'}
 if MODEL_API_KEY: headers['Authorization']='Bearer '+MODEL_API_KEY
 payload={'model':MODEL_NAME,'messages':[{'role':'system','content':system},{'role':'user','content':req.message}],'temperature':0.4}
 try:
  async with httpx.AsyncClient(timeout=90) as client:
   r=await client.post(MODEL_BASE_URL+'/chat/completions',headers=headers,json=payload); r.raise_for_status(); data=r.json()
  answer=data['choices'][0]['message']['content']
  return {'answer':answer,'module':req.module,'conversation_id':req.conversation_id or str(uuid4()),'knowledge_used':[x['id'] for x in context],'model':MODEL_NAME}
 except httpx.HTTPStatusError as e: raise HTTPException(502,detail={'code':'MODEL_UPSTREAM_ERROR','status':e.response.status_code,'message':'تعذر على مزود الموديل معالجة الطلب.'})
 except Exception: raise HTTPException(502,detail={'code':'MODEL_CONNECTION_ERROR','message':'تعذر الاتصال بالموديل. تحقق من عنوان الخادم واسم الموديل.'})
@app.post('/api/knowledge')
def add_knowledge(req:KnowledgeRequest):
 item={'id':str(uuid4()),'title':req.title,'content':req.content,'tags':req.tags,'source':req.source,'created_at':now(),'review_status':'pending'}
 with db() as c:c.execute('INSERT INTO knowledge VALUES(?,?,?,?,?,?,?)',(item['id'],item['title'],item['content'],json.dumps(item['tags'],ensure_ascii=False),item['source'],item['created_at'],item['review_status']))
 return {'item':item,'note':'حُفظت بشكل دائم للمراجعة؛ لا تُستخدم في إجابات الموديل حتى اعتمادها، ولا تغيّر أوزانه.'}
@app.get('/api/knowledge')
def list_knowledge():
 with db() as c: rows=c.execute('SELECT * FROM knowledge ORDER BY created_at DESC LIMIT 500').fetchall()
 return {'items':[dict(r) for r in rows],'count':len(rows)}
@app.post('/api/knowledge/{item_id}/review')
def review_knowledge(item_id:str, req:ReviewRequest):
 status='approved' if req.approved else 'rejected'
 with db() as c:
  cur=c.execute('UPDATE knowledge SET review_status=? WHERE id=?',(status,item_id))
  if not cur.rowcount: raise HTTPException(404,'Knowledge item not found')
 return {'id':item_id,'review_status':status}
@app.post('/api/feedback')
def add_feedback(req:FeedbackRequest):
 item={'id':str(uuid4()),**req.model_dump(),'created_at':now(),'status':'pending_review'}
 with db() as c:c.execute('INSERT INTO feedback VALUES(?,?,?,?,?,?,?,?,?)',(item['id'],item['module'],item['prompt'],item['model_answer'],item['corrected_answer'],item['note'],item['created_at'],item['status']))
 return {'item':item,'note':'التصحيح محفوظ للمراجعة ويمكن تصديره لاحقًا لمجموعة التدريب؛ لا يغيّر أوزان الموديل تلقائيًا.'}
@app.get('/api/feedback')
def list_feedback():
 with db() as c: rows=c.execute('SELECT * FROM feedback ORDER BY created_at DESC LIMIT 500').fetchall()
 return {'items':[dict(r) for r in rows],'count':len(rows)}
